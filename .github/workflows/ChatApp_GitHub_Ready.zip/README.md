# ChatApp — GitHub Ready Android Project

A starter Android messaging application with:

- Phone number login
- Firebase Phone Authentication / real SMS OTP
- OTP verification
- Persistent Firebase session
- App-generated Device ID (no IMEI)
- Home screen
- Logout
- GitHub-friendly project structure

## Requirements

- Android Studio Ladybug or newer
- Android SDK 35
- JDK 17
- A Firebase project

## Firebase setup

1. Create a Firebase project.
2. Add an Android app with package name:

   `com.chatapp`

3. Download `google-services.json`.
4. Put it at:

   `app/google-services.json`

5. In Firebase Console, enable:
   - Authentication → Sign-in method → Phone
6. Add your test phone numbers if you want Firebase test OTPs during development.
7. For production SMS OTP, configure the Firebase/Google Cloud project as required by Firebase.

## Build

Open this folder in Android Studio and let Gradle sync.

Then run the `app` configuration on an Android device or emulator.

## GitHub

Do not commit `google-services.json` if you want to keep Firebase project configuration private. The included `.gitignore` ignores it.

Suggested commands:

```bash
git init
git add .
git commit -m "Initial ChatApp Android project"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

## App flow

Country code / phone number
→ Send OTP
→ Verify OTP
→ Firebase account/session
→ Device ID registration
→ Home

## Device ID

This project creates an app-scoped random UUID and stores it in SharedPreferences. It does not read IMEI, IMSI, contacts, or other hardware identifiers.

For a production app, store the device record in Firestore after adding the Firestore SDK and your security rules.

## Important

The project is a working authentication starter, not a finished WhatsApp replacement. Chat, media upload, calls, groups, push notifications and admin features should be added as separate production modules.
